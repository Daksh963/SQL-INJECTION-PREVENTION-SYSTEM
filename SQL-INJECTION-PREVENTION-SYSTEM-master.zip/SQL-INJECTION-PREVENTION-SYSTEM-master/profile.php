<?php

echo "welcome ".$_GET["email"];

?>
